﻿using System;

namespace AzureXamarinForm
{
	public static class Constants
	{
		// Replace strings with your Azure Mobile App endpoint.
		public static string ApplicationURL = @"https://azurexamarinform.azurewebsites.net";
	}
}

